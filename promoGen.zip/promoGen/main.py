import time
import os
import threading
import random
import string
from threading import Timer

try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.common.keys import Keys
    from colorama import Back, Fore
except:
    os.system("pip install selenium")
    os.system("pip install colorama")
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.common.keys import Keys
    from colorama import Back, Fore

def usrName(length):
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for _ in range(length))

userName = usrName(8)

def streamlabs():

    driver = webdriver.Firefox()
    # chromeOption = webdriver.ChromeOptions()
    # driver = webdriver.Chrome(options=chromeOption)

    driver.implicitly_wait(20)

    driver.get("https://streamlabs.com")
    driver.set_window_size(1200, 768)


    # Click on SignUp
    try:
        driver.find_element(By.XPATH, value="/html/body/div[2]/div/div[1]/div/div[2]/div[3]/button[3]/div").click()
    except:
        driver.find_element(By.XPATH, value="/html/body/div[2]/div/div[1]/div/div/div[3]/button[3]/div").click()

    # time.sleep(30)

    # GET EMAIL
    driver.execute_script("window.open('');")
    driver.switch_to.window(driver.window_handles[1])
    driver.get("https://tempmailto.org/")
    getEmail = driver.find_element(By.XPATH, value="/html/body/div[1]/header/div/div[3]/div/div[2]/div[2]/form/div/div[1]/div[1]/div")
    email = getEmail.text
    passwd = "Password@312"


    # Streamlab section
    driver.switch_to.window(driver.window_handles[0])
    time.sleep(3000)
    driver.find_element(By.XPATH, value="/html/body/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div[6]/div/div[1]/div[1]/div/div/div[2]/form/div[1]/input").send_keys(email)
    time.sleep(.5)
    driver.find_element(By.XPATH, value="/html/body/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div[6]/div/div[1]/div[1]/div/div/div[2]/form/div[2]/div[1]/input").send_keys(passwd)

    #click on checkbox
    driver.find_element(By.XPATH, value="/html/body/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div[6]/div/div[1]/div[1]/div/div/div[2]/form/div[3]/label/input").click()
    #driver.find_element(By.XPATH, value="/html/body/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div[6]/div/div[1]/div[1]/div/div/div[2]/form/div[4]/label/input").click() #optional
    #click on SignUp
    time.sleep(.5)
    driver.find_element(By.XPATH, value="/html/body/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div[6]/div/div[1]/div[1]/div/div/div[2]/form/div[6]/button").click()

    #ENTER CODE FROM EMAIL
    driver.switch_to.window(driver.window_handles[1])
    driver.find_element(By.XPATH, value="/html/body/div[1]/div/main/div[1]/div/div[1]/div[2]/div").click()
    streamlabCode = driver.find_element(By.XPATH, value="/html/body/div[2]/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr/td/div").text
    driver.find_element(By.XPATH, value="/html/body/div[1]/div/main/div[1]/div/div[2]/div[1]/div/div[1]/svg/path").click()

    print(streamlabCode)

    driver.switch_to.window(driver.window_handles[0])
    driver.find_element(By.XPATH, value="/html/body/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div[6]/div/div[1]/div[1]/div/div/div[2]/div/div[2]/input").send_keys(streamlabCode)
    driver.find_element(By.XPATH, value="/html/body/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div[6]/div/div[1]/div[1]/div/div/div[2]/div/div[4]/button").click()
    time.sleep(5) #IMP
    driver.find_element(By.XPATH, value="/html/body/div[3]/div/div[5]/div/div[2]/div/div[3]/div[2]/button[1]/span/span").click()
    driver.find_element(By.XPATH, value="/html/body/div[3]/div/div[5]/div/div[2]/div/div[4]/button[1]").click()
    #link trovo
    driver.find_element(By.XPATH, value="/html/body/div[3]/div/div[5]/div/div[2]/div/div[3]/div/div/div[5]/div[2]").click()
    driver.find_element(By.XPATH, value="/html/body/div[1]/div[2]/div[3]/div/ul/li[2]/span").click() # click on signup
    driver.find_element(By.XPATH, value="/html/body/div[3]/div[2]/div[2]/div/div[1]/div/input").send_keys(email)
    driver.find_element(By.XPATH, value="/html/body/div[3]/div[2]/div[2]/div/div[2]/div/input").send_keys(userName)
    driver.find_element(By.XPATH, value="/html/body/div[3]/div[2]/div[2]/div/div[3]/div/input").send_keys(passwd)

    # enter dob

    driver.find_element(By.XPATH, value="/html/body/div[3]/div[2]/div[2]/div/div[4]/div/div[1]/div[1]/span").click()
    driver.find_element(By.XPATH, value="/html/body/div[3]/div[2]/div[2]/div/div[4]/div/div[1]/div[2]/ul/li[4]").click() #MONTH
    driver.find_element(By.XPATH, value="/html/body/div[3]/div[2]/div[2]/div/div[4]/div/div[2]/div[1]/input").send_keys(7) #DAY
    driver.find_element(By.XPATH, value="/html/body/div[3]/div[2]/div[2]/div/div[4]/div/div[3]/div[1]/input").send_keys(1997) #YEAR
    driver.find_element(By.XPATH, value="/html/body/div[3]/div[2]/div[2]/div/button[2]").click()

    driver.switch_to.window(driver.window_handles[1])
    time.sleep(3)
    driver.find_element(By.XPATH, value="/html/body/div[1]/div/main/div[1]/div/div[1]/div[2]/div[1]/div[2]").click()
    trovoCode = driver.find_element(By.XPATH, value="/html/body/table/tbody/tr/td/div/div[3]/div/div/div[3]/div/p/span/strong").text

    driver.switch_to.window(driver.window_handles[0])

    driver.find_element(By.XPATH, value="/html/body/div[3]/div[2]/div[2]/section/div[2]/input").send_keys(trovoCode)
    time.sleep(5)

    driver.find_element(By.XPATH, value="/html/body/div[1]/div[2]/div[3]/div/div[1]/div/input").send_keys(email)
    driver.find_element(By.XPATH, value="/html/body/div[1]/div[2]/div[3]/div/div[2]/div/input").send_keys(passwd)
    driver.find_element(By.XPATH, value="/html/body/div[1]/div[2]/div[3]/div/button").click()
    time.sleep(1)
    driver.find_element(By.XPATH, value="/html/body/div[1]/div[2]/div/section[5]/div/section/button[2]").click()

    #streamlab section after login
    driver.find_element(By.XPATH, value='/html/body/div[3]/div/div[5]/div/div[2]/div/div[3]/div[2]/button[1]/span/span').click()
    driver.find_element(By.XPATH, value='/html/body/div[3]/div/div[5]/div/div[2]/div/div[4]/button[1]/span/span').click()
    driver.find_element(By.XPATH, value='/html/body/div[3]/div/div[3]/div[3]/div[2]/div/div[4]/div[1]/div[3]/a[1]/span/span').click()
    driver.find_element(By.XPATH, value='/html/body/div[3]/div/div[3]/div[3]/div[2]/div/div[3]/div[1]/div[2]/div/div/div[5]/div/div[2]/button').click()

    #login trovo
    driver.find_element(By.XPATH, value="/html/body/div[1]/div[2]/div[3]/div/div[1]/div/input").send_keys(email)
    driver.find_element(By.XPATH, value="/html/body/div[1]/div[2]/div[3]/div/div[2]/div/input").send_keys(passwd)
    driver.find_element(By.XPATH, value="/html/body/div[1]/div[2]/div[3]/div/button").click()
    time.sleep(1)
    driver.find_element(By.XPATH, value="/html/body/div[1]/div[2]/div/section[5]/div/section/button[2]").click()

    driver.find_element(By.XPATH, value="/html/body/div[3]/div/div[3]/div[3]/div[1]/div[3]/div/div[1]/div/div[2]/a/div[2]/span").click()
    driver.find_element(By.XPATH, value="/html/body/div[3]/div/div[3]/div[3]/div[2]/div/div[4]/div[1]/div[3]/a").click()
    time.sleep(5)

    discordPromo = driver.current_url

    with open("discordPromo.txt", "a") as discPromo:
        discPromo.write(discordPromo)

    print(discordPromo)

if __name__ == '__main__':
    streamlabs()